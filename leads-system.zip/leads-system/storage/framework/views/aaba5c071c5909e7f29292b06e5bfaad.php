

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div style="padding: 30px; max-width: 1200px; margin: auto;">
        <h2 style="margin-bottom: 20px; font-size: 28px; color: #333;">All Leads</h2>

        <form method="GET" style="margin-bottom: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
            <div>
                <label for="status">Status:</label><br>
                <select name="status" id="status" style="padding: 6px 10px; min-width: 150px;">
                    <option value="">All Status</option>
                    <?php $__currentLoopData = ['New', 'Contacted', 'Converted', 'Lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(request('status') == $status ? 'selected' : ''); ?>>
                            <?php echo e($status); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label for="lead_source">Lead Source:</label><br>
                <select name="lead_source" id="lead_source" style="padding: 6px 10px; min-width: 150px;">
                    <option value="">All Sources</option>
                    <?php $__currentLoopData = $leads->pluck('lead_source')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($source); ?>" <?php echo e(request('lead_source') == $source ? 'selected' : ''); ?>>
                            <?php echo e($source); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <br>
                <button type="submit"
                    style="padding: 8px 16px; background-color: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Filter
                </button>
            </div>
        </form>

        <?php if(session('success')): ?>
            <p style="color: green; margin-bottom: 15px;"><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <div style="overflow-x:auto;">
            <table style="width: 100%; border-collapse: collapse; background-color: #fff;">
                <thead>
                    <tr style="background-color: #f2f2f2;">
                        <th style="padding: 10px; border: 1px solid #ddd;">Name</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Email</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Phone</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Source</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Status</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Assigned To</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Remarks</th>
                        <th style="padding: 10px; border: 1px solid #ddd;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->name); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->email); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->phone); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->lead_source); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->status); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->assignedUser->name ?? '-'); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;"><?php echo e($lead->remarks); ?></td>
                            <td style="padding: 10px; border: 1px solid #ddd;">
                                <a href="<?php echo e(route('leads.edit', $lead->id)); ?>"
                                    style="margin-right: 8px; color: #007bff;">Edit</a>
                                <a href="<?php echo e(route('leads.delete', $lead->id)); ?>" style="color: red;"
                                    onclick="return confirm('Are you sure?')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" style="padding: 10px; border: 1px solid #ddd; text-align: center;">No leads
                                found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Leads-Management-System-Laravel\Leads-Management-System-Laravel\leads-system\resources\views/leads/index.blade.php ENDPATH**/ ?>