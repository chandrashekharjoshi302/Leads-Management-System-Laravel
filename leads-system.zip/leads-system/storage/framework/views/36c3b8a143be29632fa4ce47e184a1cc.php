

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div
        style="max-width: 600px; margin: 30px auto; padding: 30px; border: 1px solid #ddd; border-radius: 10px; background-color: #f9f9f9; box-shadow: 0 0 10px rgba(0,0,0,0.05);">
        <h2 style="margin-bottom: 20px; text-align: center; color: #333;">Create New Lead</h2>

        <?php if($errors->any()): ?>
            <div
                style="background-color: #ffe6e6; border: 1px solid #ff0000; padding: 10px; margin-bottom: 20px; border-radius: 5px; color: #900;">
                <ul style="margin: 0; padding-left: 20px;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('leads.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold;">Name:</label><br>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" style="width: 100%; padding: 8px;">
            </div>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold;">Email:</label><br>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" style="width: 100%; padding: 8px;">
            </div>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold;">Phone:</label><br>
                <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" style="width: 100%; padding: 8px;">
            </div>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold;">Lead Source:</label><br>
                <input type="text" name="lead_source" value="<?php echo e(old('lead_source')); ?>"
                    style="width: 100%; padding: 8px;">
            </div>

            <div style="margin-bottom: 15px;">
                <label style="font-weight: bold;">Status:</label><br>
                <select name="status" style="width: 100%; padding: 8px;">
                    <?php $__currentLoopData = ['New', 'Contacted', 'Converted', 'Lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e(old('status') == $status ? 'selected' : ''); ?>>
                            <?php echo e($status); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <?php if(auth()->user()->role === 'admin'): ?>
                <div style="margin-bottom: 15px;">
                    <label style="font-weight: bold;">Assigned To:</label><br>
                    <select name="assigned_to" style="width: 100%; padding: 8px;">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('assigned_to') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>

            <div style="margin-bottom: 20px;">
                <label style="font-weight: bold;">Remarks:</label><br>
                <textarea name="remarks" style="width: 100%; padding: 8px; height: 100px;"><?php echo e(old('remarks')); ?></textarea>
            </div>

            <button type="submit"
                style="width: 100%; background-color: #28a745; color: white; border: none; padding: 10px 0; font-size: 16px; border-radius: 5px; cursor: pointer;">
                Create Lead
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Leads-Management-System-Laravel\Leads-Management-System-Laravel\leads-system\resources\views/leads/create.blade.php ENDPATH**/ ?>