

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div style="padding: 20px;">
        <h2>Edit Lead</h2>

        <?php if($errors->any()): ?>
            <div style="color: red;">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('leads.update', $lead->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label>Name:</label><br>
            <input type="text" name="name" value="<?php echo e(old('name', $lead->name)); ?>"><br><br>

            <label>Email:</label><br>
            <input type="email" name="email" value="<?php echo e(old('email', $lead->email)); ?>"><br><br>

            <label>Phone:</label><br>
            <input type="text" name="phone" value="<?php echo e(old('phone', $lead->phone)); ?>"><br><br>

            <label>Lead Source:</label><br>
            <input type="text" name="lead_source" value="<?php echo e(old('lead_source', $lead->lead_source)); ?>"><br><br>

            <label>Status:</label><br>
            <select name="status">
                <?php $__currentLoopData = ['New', 'Contacted', 'Converted', 'Lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(old('status', $lead->status) == $status ? 'selected' : ''); ?>>
                        <?php echo e($status); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>

            <label>Assigned To:</label><br>
            <select name="assigned_to">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"
                        <?php echo e(old('assigned_to', $lead->assigned_to) == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select><br><br>

            <label>Remarks:</label><br>
            <textarea name="remarks"><?php echo e(old('remarks', $lead->remarks)); ?></textarea><br><br>

            <button type="submit">Update Lead</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Leads-Management-System-Laravel\Leads-Management-System-Laravel\leads-system\resources\views/leads/edit.blade.php ENDPATH**/ ?>