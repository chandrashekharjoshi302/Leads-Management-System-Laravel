

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container py-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="mb-4">Dashboard</h2>

                <div class="mb-3">
                    <h5>Total Leads: <span class="badge bg-primary"><?php echo e($totalLeads); ?></span></h5>
                </div>

                <div class="mb-4">
                    <h5>Status-wise Breakdown</h5>
                    <ul class="list-group">
                        <?php $__currentLoopData = $statusCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($status); ?>

                                <span class="badge bg-secondary"><?php echo e($count); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <?php if(auth()->user()->role === 'sales'): ?>
                    <div class="alert alert-info">
                        <strong>Your Assigned Leads:</strong> <?php echo e($userLeadsCount); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\Leads-Management-System-Laravel\Leads-Management-System-Laravel\leads-system\resources\views/dashboard.blade.php ENDPATH**/ ?>